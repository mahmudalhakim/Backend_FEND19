<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->

    <link rel="stylesheet" href=" https://stackpath.bootstrapcdn.com/bootswatch/4.4.1/darkly/bootstrap.min.css">
    <title>Videobutiken</title>
  </head>
  <body class="container">
  <h1 class="text-center"><a href="index.php">Videobutiken</a></h1>
  <h2 class="text-center"><a href="show-orders.php">Visa alla beställningar</a></h2>